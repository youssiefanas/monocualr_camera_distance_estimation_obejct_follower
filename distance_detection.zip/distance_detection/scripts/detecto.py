import rospy
import cv2
from std_msgs.msg import String, Float32
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from ultralytics import YOLO
from ultralytics.yolo.utils.plotting import Annotator
import sys
import time 


def calculate_distance(focal_length, object_width, pixel_width):
    pixel_width = float(pixel_width)
    distance = (focal_length * object_width) / pixel_width
    return distance

def focal_length_finder (measured_distance, real_width, width_in_rf):
    focal_length = (width_in_rf * measured_distance) / real_width
    return focal_length

bridge = CvBridge() #Create a bridge

def image_callback(ros_image):
    print('got an image')
    global bridge

    try:
        cv_image = bridge.imgmsg_to_cv2(ros_image, 'bgr8')
    except CvBridgeError as e:
        print(e)

    #from now you can work with opencv commands:
    cv2.waitKey(1)
    #calculate fps 
    prev_time = time.time()

    results=model.predict(cv_image,show = False)

    fps = 1 / (time.time() - prev_time)
    fps = int(fps)

    for r in results:
        annotator = Annotator(cv_image)
        boxes = r.boxes
        for box in boxes:
            b = box.xyxy[0]  # get box coordinates in (top, left, bottom, right) format
            c = box.cls
            w = box.xywh[0][2]
            h = box.xywh[0][3]
            distance = calculate_distance(870, 20, w)
            distance = round(distance, 2)
            object_detected.publish(model.names[int(c)])
            object_detected_dist.publish(distance)
            annotator.box_label(b, model.names[int(c)] + " Distance: " + str(distance)+" FPS: "+str(fps))
    cv_image = annotator.result()
    ros_image = bridge.cv2_to_imgmsg(cv_image)
    image_pub.publish(ros_image)
    cv2.imshow("Image_window", cv_image)



def main(args):
    rospy.init_node('image_converter', anonymous=True)
    image_sub = rospy.Subscriber("/usb_cam/image_raw", Image, image_callback)
    global image_pub, object_detected_dist, object_detected
    global model
    model = YOLO("/home/anas/catkin_ws/src/distance_detection/best(1).pt")
    object_detected = rospy.Publisher("/object_detected",String,queue_size=10)
    object_detected_dist = rospy.Publisher("/object_dist",Float32,queue_size=10)
    image_pub = rospy.Publisher("/detected_dist",Image,queue_size=10)



    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)

